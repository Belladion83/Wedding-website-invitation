const C = window.WEDDING_CONFIG;
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const guestId = params.get('id') || params.get('guest') || '';
const guestName = params.get('name') || '';
let galleryIndex = 0;
function setText(id, value){ const el=$(id); if(el) el.textContent = value || ''; }
function setSrc(id, value){ const el=$(id); if(el) el.src = value || ''; }
function initContent(){
  setText('introGroom', C.groomShortName); setText('introBride', C.brideShortName); setText('introDate', C.displayDate); setText('introType', C.eventType);
  setSrc('envPhoto1', C.envelopePhoto1); setSrc('envPhoto2', C.envelopePhoto2); setText('envDate1', C.displayDate); setText('envDate2', C.displayDate);
  document.querySelector('.hero-bg').style.backgroundImage = `url('${C.heroImage}')`;
  setText('heroNames', `${C.groomFullName} & ${C.brideFullName}`); setText('heroDate', C.displayDate);
  if(guestName) setText('inviteeLine', `Kính gửi ${guestName}`);
  setSrc('groomPhoto', C.couple.groom.photo); setSrc('bridePhoto', C.couple.bride.photo);
  setText('groomName', C.couple.groom.name); setText('groomBirthday', `☷ ${C.couple.groom.birthday}`); setText('groomZodiac', `✧ ${C.couple.groom.zodiac}`); setText('groomAddress', `⌖ ${C.couple.groom.address}`);
  setText('brideName', C.couple.bride.name); setText('brideBirthday', `☷ ${C.couple.bride.birthday}`); setText('brideZodiac', `✧ ${C.couple.bride.zodiac}`); setText('brideAddress', `⌖ ${C.couple.bride.address}`);
  setText('storyTitle', C.storyTitle); setText('storyText', C.storyText);
  setText('groomSideTitle', C.families.groomSide.title); setText('groomFather', C.families.groomSide.father); setText('groomMother', C.families.groomSide.mother); setText('groomFamAddress', C.families.groomSide.address);
  setText('brideSideTitle', C.families.brideSide.title); setText('brideFather', C.families.brideSide.father); setText('brideMother', C.families.brideSide.mother); setText('brideFamAddress', C.families.brideSide.address);
  setText('venue', C.event.venue); setText('venueAddress', C.event.address); setText('eventDay', C.event.dayLabel); setText('eventDate', C.displayDate); setText('eventTime', C.event.timeLabel); $('mapBtn').href = C.googleMapsUrl;
  setText('brideGiftTitle', C.banking.bride.title); setSrc('brideQr', C.banking.bride.qr); setText('brideBank', `Ngân hàng: ${C.banking.bride.bank}`); setText('brideAcc', `STK: ${C.banking.bride.accountNo}`); setText('brideNameBank', `Tên TK: ${C.banking.bride.accountName}`); setText('brideMemo', `Nội dung CK: ${C.banking.bride.memo}`);
  setText('groomGiftTitle', C.banking.groom.title); setSrc('groomQr', C.banking.groom.qr); setText('groomBank', `Ngân hàng: ${C.banking.groom.bank}`); setText('groomAcc', `STK: ${C.banking.groom.accountNo}`); setText('groomNameBank', `Tên TK: ${C.banking.groom.accountName}`); setText('groomMemo', `Nội dung CK: ${C.banking.groom.memo}`);
  $('bgMusic').src = C.musicUrl;
  const nameInput = document.querySelector('[name="guestName"]'); if(guestName){ nameInput.value = guestName; nameInput.readOnly = true; }
  renderGallery();
}
function renderGallery(){
  const grid = $('galleryGrid'); grid.innerHTML=''; const imgs=C.gallery || []; const shown=imgs.slice(0,16);
  shown.forEach((src,i)=>{ const d=document.createElement('div'); d.className='thumb'; d.innerHTML=`<img src="${src}" alt="Ảnh cưới ${i+1}">`; if(i===15 && imgs.length>16){ const m=document.createElement('div'); m.className='more'; m.textContent=`+${imgs.length-15}`; d.appendChild(m); } d.onclick=()=>openLightbox(i); grid.appendChild(d); });
}
function openLightbox(i){ galleryIndex=i; $('lightbox').classList.add('open'); $('lightboxImg').src=C.gallery[galleryIndex]; }
function moveGallery(step){ galleryIndex=(galleryIndex+step+C.gallery.length)%C.gallery.length; $('lightboxImg').src=C.gallery[galleryIndex]; }
function startMusic(){ const a=$('bgMusic'); a.play().catch(()=>{}); $('musicToggle').classList.remove('hidden'); }
function countdown(){ const target=new Date(C.weddingDate).getTime(); const now=Date.now(); let diff=Math.max(0,target-now); const d=Math.floor(diff/86400000); diff-=d*86400000; const h=Math.floor(diff/3600000); diff-=h*3600000; const m=Math.floor(diff/60000); diff-=m*60000; const s=Math.floor(diff/1000); const vals=[d,h,m,s]; document.querySelectorAll('#countdown strong').forEach((el,i)=>el.textContent=String(vals[i]).padStart(2,'0')); }
function localSave(payload){ const arr=JSON.parse(localStorage.getItem('wedding_rsvp')||'[]'); arr.push(payload); localStorage.setItem('wedding_rsvp',JSON.stringify(arr)); }
async function submitRsvp(e){ e.preventDefault(); const fd=new FormData(e.target); const payload={ timestamp:new Date().toISOString(), guestId, guestName:fd.get('guestName'), wish:fd.get('wish'), attending:fd.get('attending'), companions:fd.get('companions'), guestOf:fd.get('guestOf')}; $('formStatus').textContent='Đang gửi xác nhận...';
  try{ if(C.googleAppsScriptUrl){ await fetch(C.googleAppsScriptUrl,{method:'POST',mode:'no-cors',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); } localSave(payload); $('formStatus').textContent='Cảm ơn Quý khách! Cô dâu và chú rể đã nhận được xác nhận.'; e.target.reset(); if(guestName){ const nameInput=document.querySelector('[name="guestName"]'); nameInput.value=guestName; nameInput.readOnly=true;} }
  catch(err){ localSave(payload); $('formStatus').textContent='Đã lưu xác nhận trên thiết bị. Vui lòng gửi lại nếu cần.'; }
}
function initEvents(){ $('openEnvelope').onclick=()=> $('envelope').classList.add('opened'); $('enterSite').onclick=()=>{ $('intro').classList.add('hidden'); $('site').classList.remove('hidden'); startMusic(); setTimeout(()=>window.scrollTo(0,0),0);}; $('musicStart').onclick=startMusic; $('musicToggle').onclick=()=>{ const a=$('bgMusic'); if(a.paused){a.play(); $('musicToggle').textContent='♪'} else {a.pause(); $('musicToggle').textContent='♫'} }; $('rsvpForm').onsubmit=submitRsvp; $('giftBtn').onclick=()=> $('giftSheet').classList.add('open'); $('closeGift').onclick=$('backInvite').onclick=()=> $('giftSheet').classList.remove('open'); $('closeLightbox').onclick=()=> $('lightbox').classList.remove('open'); $('prevImg').onclick=()=>moveGallery(-1); $('nextImg').onclick=()=>moveGallery(1); }
function revealOnScroll(){ const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12}); document.querySelectorAll('.section-reveal').forEach(el=>io.observe(el)); }
initContent(); initEvents(); revealOnScroll(); countdown(); setInterval(countdown,1000);
