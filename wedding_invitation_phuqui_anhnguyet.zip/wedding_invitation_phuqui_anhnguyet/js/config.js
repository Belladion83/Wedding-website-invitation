window.WEDDING_CONFIG = {
  groomShortName: 'Phú Quí',
  brideShortName: 'Ánh Nguyệt',
  groomFullName: 'Trần Ngô Phú Quí',
  brideFullName: 'Ánh Nguyệt',
  weddingDate: '2026-06-29T18:00:00+07:00',
  displayDate: '29 . 06 . 2026',
  eventType: 'TIỆC BÁO HỶ',
  musicUrl: 'assets/music/background.mp3',
  googleMapsUrl: 'https://maps.google.com/?q=Jolie%20Wedding%20%26%20Event%20177%20Phan%20Chu%20Trinh%20Binh%20Thanh%20Ho%20Chi%20Minh',
  googleAppsScriptUrl: '', // Dán URL Web App Google Apps Script tại đây để gửi RSVP về Google Sheet
  adminPassword: '29062026',
  heroImage: 'assets/images/venue.jpg',
  envelopePhoto1: 'assets/images/venue.jpg',
  envelopePhoto2: 'assets/images/paper-invite.jpg',
  couple: {
    groom: { name: 'TRẦN NGÔ PHÚ QUÍ', birthday: '12 . 05 . 1996', zodiac: 'Kim Ngưu', address: 'TP. Hồ Chí Minh', photo: 'assets/images/groom.svg' },
    bride: { name: 'ÁNH NGUYỆT', birthday: '21 . 09 . 1998', zodiac: 'Xử Nữ', address: 'TP. Hồ Chí Minh', photo: 'assets/images/bride.svg' }
  },
  storyTitle: 'OUR STORY',
  storyText: 'Hành trình yêu thương của chúng tôi sẽ được viết tại đây. Bạn có thể thay đổi nội dung này trong file js/config.js để kể lại câu chuyện của cô dâu và chú rể theo cách riêng, nhẹ nhàng và chân thành nhất.',
  families: {
    groomSide: { title: 'NHÀ TRAI', father: 'Ông: Trần Văn Nam', mother: 'Bà: Nguyễn Thị Lan', address: 'Địa chỉ: 123 Nguyễn Huệ, P. Bến Nghé, Q.1, TP. HCM' },
    brideSide: { title: 'NHÀ GÁI', father: 'Ông: Lê Hoàng Phúc', mother: 'Bà: Phạm Thị Mai', address: 'Địa chỉ: 456 Lê Lợi, P. Bến Thành, Q.1, TP. HCM' }
  },
  event: {
    venue: 'TRUNG TÂM HỘI NGHỊ & TIỆC CƯỚI\nJOLIE WEDDING & EVENT',
    address: '177 Phan Chu Trinh, Phường 13, Quận Bình Thạnh, TP. Hồ Chí Minh',
    dayLabel: 'CHỦ NHẬT',
    timeLabel: '18:00'
  },
  gallery: [
    'assets/images/venue.jpg','assets/images/paper-invite.jpg','assets/images/design-preview.png','assets/images/venue.jpg',
    'assets/images/paper-invite.jpg','assets/images/design-preview.png','assets/images/venue.jpg','assets/images/paper-invite.jpg',
    'assets/images/design-preview.png','assets/images/venue.jpg','assets/images/paper-invite.jpg','assets/images/design-preview.png',
    'assets/images/venue.jpg','assets/images/paper-invite.jpg','assets/images/design-preview.png','assets/images/venue.jpg',
    'assets/images/paper-invite.jpg','assets/images/design-preview.png','assets/images/venue.jpg','assets/images/paper-invite.jpg'
  ],
  banking: {
    bride: { title: 'Mừng cưới cô dâu', bank: 'Vietcombank', accountNo: '1234 5678 9999', accountName: 'ANH NGUYET', qr: 'assets/qr/bride-qr.svg', memo: 'Mung cuoi Anh Nguyet' },
    groom: { title: 'Mừng cưới chú rể', bank: 'Techcombank', accountNo: '9999 8888 7777', accountName: 'TRAN NGO PHU QUI', qr: 'assets/qr/groom-qr.svg', memo: 'Mung cuoi Phu Qui' }
  }
};
