WEBSITE INVITATION - PHÚ QUÍ & ÁNH NGUYỆT

1) Mở thử trên máy:
- Giải nén file ZIP.
- Mở index.html bằng trình duyệt.
- Trang quản trị local: admin.html, mật khẩu mặc định: 29062026.

2) Chỉnh nội dung thiệp:
- Mở file js/config.js.
- Sửa tên, ngày, giờ, thông tin gia đình, nhà hàng, Google Maps, lời story, ngân hàng, QR.
- Thay ảnh trong assets/images và cập nhật đường dẫn trong config.js.
- Thay QR thật tại assets/qr/bride-qr.svg và assets/qr/groom-qr.svg bằng file PNG/JPG/SVG thật.
- Thêm nhạc nền tại assets/music/background.mp3, hoặc sửa musicUrl trong config.js.

3) Link cá nhân hóa khách mời:
- Ví dụ: index.html?id=A001&name=Anh%20Nguyen%20Van%20A
- Khi khách mở link, thiệp sẽ hiện: Kính gửi Anh Nguyen Van A.
- RSVP sẽ lưu kèm Guest ID.

4) Gửi RSVP về Google Sheet:
- Tạo Google Sheet.
- Extensions > Apps Script.
- Dán code trong file google-apps-script.gs.
- Deploy > New deployment > Web app.
- Execute as: Me. Who has access: Anyone.
- Copy Web App URL và dán vào googleAppsScriptUrl trong js/config.js.

5) Deploy online:
- Có thể upload toàn bộ folder lên Netlify, Vercel, GitHub Pages hoặc hosting bất kỳ.
