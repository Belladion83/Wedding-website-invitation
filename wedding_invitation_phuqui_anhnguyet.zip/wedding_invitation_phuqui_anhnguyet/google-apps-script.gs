function doPost(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheetName = 'RSVP';
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    sheet.appendRow(['Timestamp','Guest ID','Tên khách','Tham dự','Đi cùng','Khách của','Lời chúc']);
  }
  const data = JSON.parse(e.postData.contents || '{}');
  sheet.appendRow([
    data.timestamp || new Date(),
    data.guestId || '',
    data.guestName || '',
    data.attending || '',
    data.companions || '',
    data.guestOf || '',
    data.wish || ''
  ]);
  return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
}
